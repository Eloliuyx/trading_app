// src/store.ts
import { create } from "zustand";

/**
 * ============================================================
 * Trading_App 全局数据 Store（只实现 F1-F6 多因子过滤）
 * ============================================================
 *
 * 设计要点：
 * 1. 所有用于筛选的布尔信号，优先信任后端导出的 pass_xxx 字段；
 * 2. 前端不重复做复杂计算，只做「读取 + 组合展示」；
 * 3. 缺数据时一律 fail-closed（返回 false），保证确定性与可解释性；
 * 4. F1-F6 的文案、逻辑和字段命名，与 backend/export_universe.py 完全对齐。
 */

/** ========= 基础类型 ========= */

/** K线价格线（个股自定义水平线） */
export type PriceLine = { id: string; price: number; title?: string };

/** 个股笔记：仅存储在本机 localStorage，用于主观记录 */
export type Note = { id: string; ts: string; text: string };

/** 市场快照：来自 universe.json 顶层信息 */
export type MarketSnapshot = {
  asof?: string;            // universe 生成日期（多数情况下是最近交易日）
  last_bar_date?: string;   // 底层行情的最后交易日（预留）
  rules_version?: string;   // 规则版本号（方便未来做回测/对比）
  status?: "OK" | "NO_DATA" | "ERROR";
  error?: string;
  [k: string]: any;         // 允许扩展字段
};

/**
 * 单只股票（列表 & 详情视图的核心实体）
 *
 * 重要：
 * - backend 会输出顶层字段 + features 子对象；
 * - loadMarket 时我们会把 features 扁平合并进来；
 * - 因此这里用 [k: string]: any 允许访问 pass_xxx / 指标 等衍生字段。
 */
export type StockItem = {
  symbol: string;
  name: string;
  industry?: string;
  market?: string;
  last_date?: string;
  is_st?: boolean;
  score?: number;     // 预留：综合评分（可选）
  bucket?: string;    // 预留：分组标签（可选）
  reasons?: string[]; // 预留：机器解读文案（可选）
  [k: string]: any;
};

/** 标准化后的 K 线 Bar，用于 lightweight-charts 等组件 */
export type KLineBar = {
  time: string | number; // 日期或时间戳
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;       // 可选：部分源没有量
};

/** ========= 多因子 F1-F6 ========= */

/**
 * 当前版本只启用 F1-F6：
 * - F1 剔除风险股/ST            -> is_st
 * - F2 强流动性                 -> pass_liquidity_v2
 * - F3 合理价格区间             -> pass_price_compliance
 * - F4 放量确认                 -> pass_volume_confirm
 * - F5 多头趋势结构             -> pass_trend
 * - F6 强板块龙头               -> pass_industry_leader
 */
export type FKey = "F1" | "F2" | "F3" | "F4" | "F5" | "F6";

/**
 * FilterState：
 * - q: 文本搜索（代码 / 名称关键字）
 * - F1-F6: 是否启用对应因子过滤（true=启用）
 */
export type FilterState = {
  q: string;
} & { [K in FKey]: boolean };

/** 默认筛选：仅搜索为空，所有因子关闭（用户手动逐个打开） */
const defaultFilter: FilterState = {
  q: "",
  F1: false,
  F2: false,
  F3: false,
  F4: false,
  F5: false,
  F6: false,
};

/**
 * FactorConfig:
 * - key: F1-F6
 * - label: 展示在 UI 上的名称
 * - desc: 规则解释（用于回顾/文案，对用户友好）
 * - test: 纯函数判定：给定一条 StockItem，这个因子是否“通过”
 *
 * 重要：
 * - test 只读 StockItem（含后端 pass_xxx 字段），不访问全局状态；
 * - 逻辑与 backend/export_universe.py 中的定义保持一一对应。
 */
type FactorConfig = {
  key: FKey;
  label: string;
  desc: string;
  test: (s: StockItem) => boolean;
};

/**
 * ============================================================
 * F1-F6 因子定义（单一真相来源：此处逻辑 = 筛选逻辑 = 标签展示逻辑）
 * ============================================================
 */
export const FACTOR_CONFIG: FactorConfig[] = [
  /**
   * F1 剔除风险股/ST
   * - 使用后端提供的 is_st 标记；
   * - ST / *ST / 其他高风险标记的股票一律不通过；
   * - test 返回 true 表示“通过筛选”（即不是 ST）。
   */
  {
    key: "F1",
    label: "F1 剔除风险股/ST",
    desc: "排除 ST、*ST 及后端标记的高风险标的",
    test: (s) => s.is_st !== true,
  },

  /**
   * F2 强流动性
   * - 完全依赖后端 pass_liquidity_v2；
   * - 后端口径（简要）：
   *     - 60日均成交额 ≥ 500 万元
   *     - 60日均换手率 ≥ 0.8%
   *     - 当日换手率 ≥ 0.6%
   * - 前端只做布尔读取，不做数值重算。
   */
  {
    key: "F2",
    label: "F2 强流动性",
    desc: "近60日均成交额 ≥ 500万元，均换手率 ≥ 0.8%，当日换手率 ≥ 0.6%",
    test: (s) => s.pass_liquidity_v2 === true,
  },

  /**
   * F3 合理价格区间
   * - 使用后端 pass_price_compliance：
   *     - 当前收盘价在 [3, 80] 区间内返回 true；
   */
  {
    key: "F3",
    label: "F3 合理价格区间",
    desc: "当前股价位于 3 - 80 元区间内",
    test: (s) => s.pass_price_compliance === true,
  },

  /**
   * F4 放量确认
   * - 使用后端 pass_volume_confirm：
   *   后端当前口径（简要）：
   *     - 基于全市场分位的量能强度 pct_vr
   *     - 或自身 vol_ratio20 ≥ 1.2（今日量 ≥ 20日均量 1.2 倍）
   *     - 且 price_ok（收盘价不低于前一日）
   * - 前端不重复计算，只读 pass_volume_confirm。
   */
  {
    key: "F4",
    label: "F4 放量确认",
    desc: "放量进入市场前列，且价格不弱于前一日（由后端 pass_volume_confirm 判定）",
    test: (s) => s.pass_volume_confirm === true,
  },

  /**
   * F5 多头趋势结构
   * - 使用后端 pass_trend；
   * - 后端数学定义：
   *     1) MA5, MA13, MA39, MA5_shift_5, Close 均为有效数值；
   *     2) 多头排列：MA5 >= MA13 >= MA39；
   *     3) Close > MA13；
   *     4) (MA5 - MA5_shift_5) / MA5_shift_5 ≥ 1.5%；
   * - 前端只做布尔读取。
   */
  {
    key: "F5",
    label: "F5 多头趋势结构",
    desc: "5/13/39 日均线多头排列，收盘价在均线之上，且 5 日均线近 5 个交易日上升幅度 ≥ 1.5%",
    test: (s) => s.pass_trend === true,
  },

  /**
   * F6 强板块龙头
   * - 使用后端 pass_industry_leader；
   * - 后端定义（基于 RS20）：
   *     - industry_rs20：行业内个股 RS20 中位数；
   *     - industry_rs20_pct：行业强度在全市场中的分位；
   *     - strong_industry = industry_rs20_pct >= 0.6 （前 40% 行业）；
   *     - rank_in_industry_by_rs20：个股在本行业内按 RS20 从高到低排名；
   *     - leader_in_industry = rank_in_industry_by_rs20 <= min(5, industry_size)；
   *     - pass_industry_leader = strong_industry && leader_in_industry。
   * - 含义：只在强势行业中，选龙一〜龙五。
   */
  {
    key: "F6",
    label: "F6 强板块龙头",
    desc: "所在行业为强势板块（20日行业 RS20 位于前40%），且个股为该行业 RS20 排名前列（龙一〜龙五）",
    test: (s) => s.pass_industry_leader === true,
  },
];

/** ========= 工具函数：数据加载 & 标准化 ========= */

/** 按 URL 拉取 JSON（禁缓存，便于日更调试） */
async function fetchJSON(url: string) {
  const res = await fetch(url, { cache: "no-cache" });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  return res.json();
}

/** 按 URL 拉取文本（用于 CSV/K 线） */
async function fetchText(url: string) {
  const res = await fetch(url, { cache: "no-cache" });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${url}`);
  return res.text();
}

/**
 * JSON -> 标准化 K线
 * 支持多种常见字段命名：
 * - time/date/Date/trade_date
 * - open/high/low/close (大小写)
 * - volume/vol
 */
function normalizeKlineFromJson(raw: any): KLineBar[] {
  const arr: any[] =
    Array.isArray(raw) ? raw :
    Array.isArray(raw.list) ? raw.list :
    Array.isArray(raw.bars) ? raw.bars :
    [];
  return arr
    .map((b) => {
      const time = b.time ?? b.date ?? b.Date ?? b.trade_date;
      const open = b.open ?? b.Open;
      const high = b.high ?? b.High;
      const low = b.low ?? b.Low;
      const close = b.close ?? b.Close;
      const vol = b.volume ?? b.Volume ?? b.vol;
      if (
        time === undefined ||
        open === undefined ||
        high === undefined ||
        low === undefined ||
        close === undefined
      ) {
        return null;
      }
      return {
        time,
        open: Number(open),
        high: Number(high),
        low: Number(low),
        close: Number(close),
        volume: vol != null ? Number(vol) : undefined,
      } as KLineBar;
    })
    .filter(Boolean) as KLineBar[];
}

/**
 * CSV(Date,Open,High,Low,Close,Volume) -> 标准化 K线
 * - 忽略异常行（价格无法解析）；
 * - Volume 可缺失。
 */
function normalizeKlineFromCsv(text: string): KLineBar[] {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length <= 1) return [];
  const headers = lines[0].split(",").map((s) => s.trim());
  const idx = (name: string) =>
    headers.findIndex((h) => h.toLowerCase() === name.toLowerCase());
  const iDate = idx("Date");
  const iOpen = idx("Open");
  const iHigh = idx("High");
  const iLow = idx("Low");
  const iClose = idx("Close");
  const iVol = idx("Volume");
  if (iDate < 0 || iOpen < 0 || iHigh < 0 || iLow < 0 || iClose < 0) {
    return [];
  }
  const out: KLineBar[] = [];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i]) continue;
    const cols = lines[i].split(",");
    const time = cols[iDate];
    const open = Number(cols[iOpen]);
    const high = Number(cols[iHigh]);
    const low = Number(cols[iLow]);
    const close = Number(cols[iClose]);
    const vol = iVol >= 0 ? Number(cols[iVol]) : undefined;
    if ([open, high, low, close].some((v) => Number.isNaN(v))) continue;
    out.push({ time, open, high, low, close, volume: vol });
  }
  return out;
}

/** ========= notes 持久化（本地） ========= */

const NOTES_KEY = "ta_notes_v1";

function loadInitialNotesMap(): Record<string, Note[]> {
  if (typeof window === "undefined") return {};
  try {
    const raw = window.localStorage.getItem(NOTES_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === "object" ? parsed : {};
  } catch {
    return {};
  }
}

function saveNotesMap(map: Record<string, Note[]>) {
  if (typeof window === "undefined") return;
  try {
    window.localStorage.setItem(NOTES_KEY, JSON.stringify(map));
  } catch {
    // 本地存储失败不影响主流程
  }
}

/** ========= Store 主体 ========= */

type DataStore = {
  market: MarketSnapshot | null;
  stocks: StockItem[];
  selectedSymbol: string | null;
  filter: FilterState;

  klineMap: Record<string, KLineBar[]>;      // symbol -> K线
  lineMap: Record<string, PriceLine[]>;      // symbol -> 自定义水平线
  notesMap: Record<string, Note[]>;          // symbol -> 本地笔记

  loadMarket: () => Promise<void>;

  setFilter: (patch: Partial<FilterState>) => void;
  toggleFlag: (key: FKey) => void;

  setSelectedSymbol: (symbol: string | null) => void;

  loadKline: (symbol: string) => Promise<void>;

  getLines: (symbol: string) => PriceLine[];
  addLine: (symbol: string, line: PriceLine) => void;
  removeLine: (symbol: string, id: string) => void;

  getNotes: (symbol: string) => Note[];
  addNote: (symbol: string, text: string) => void;
  deleteNote: (symbol: string, id: string) => void;
};

export const useDataStore = create<DataStore>((set, get) => ({
  market: null,
  stocks: [],
  selectedSymbol: null,
  filter: defaultFilter,
  klineMap: {},
  lineMap: {},
  notesMap: loadInitialNotesMap(),

  /**
   * 加载 universe.json：
   * - 优先读取 /out/universe.json（回测/导出目录）
   * - 失败时回退到 /universe.json
   * - 展平 features 到顶层，方便直接访问 pass_xxx / 指标
   */
  async loadMarket() {
    try {
      let raw: any;
      try {
        raw = await fetchJSON("/out/universe.json");
      } catch {
        raw = await fetchJSON("/universe.json");
      }

      let listRaw: any[] = [];
      let asof: string | undefined;
      let lastBarDate: string | undefined;
      let rulesVersion: string | undefined;

      if (Array.isArray(raw)) {
        // 兼容旧版：直接是列表
        listRaw = raw;
      } else if (Array.isArray(raw.list)) {
        // 推荐结构：{ asof, last_bar_date, rules_version, list: [...] }
        listRaw = raw.list;
        asof = raw.asof;
        lastBarDate = raw.last_bar_date;
        rulesVersion = raw.rules_version;
      } else {
        throw new Error("universe.json format invalid");
      }

      const list: StockItem[] = listRaw.map((it) => {
        const { features, ...rest } = it;
        // 约定：features 的字段不会与顶层冲突，有冲突时可改成白名单挑选
        return { ...rest, ...(features || {}) } as StockItem;
      });

      const market: MarketSnapshot = {
        asof,
        last_bar_date: lastBarDate,
        rules_version: rulesVersion,
        status: list.length ? "OK" : "NO_DATA",
      };

      set({ market, stocks: list });
    } catch (e: any) {
      console.error("[loadMarket] failed:", e);
      set({
        market: {
          status: "ERROR",
          error: e?.message || String(e),
        },
        stocks: [],
      });
    }
  },

  /** 合并更新筛选条件（q 或某些 FKey） */
  setFilter(patch) {
    set((state) => ({
      filter: { ...state.filter, ...patch },
    }));
  },

  /** 单个因子开关切换，用于 FilterPanel 的 checkbox */
  toggleFlag(key) {
    set((state) => ({
      filter: { ...state.filter, [key]: !state.filter[key] },
    }));
  },

  /** 设置当前选中的股票，用于左侧列表 / K 线 / 详情联动 */
  setSelectedSymbol(symbol) {
    set({ selectedSymbol: symbol });
  },

  /**
   * 懒加载单只股票的 K 线数据：
   * - 先尝试 JSON（out/kline），再尝试 CSV（/data）
   * - 若已缓存则不重复请求
   */
  async loadKline(symbol) {
    if (!symbol) return;
    const cached = get().klineMap[symbol];
    if (cached && cached.length) return;

    const jsonUrls = [
      `/out/${symbol}.json`,
      `/out/kline/${symbol}.json`,
      `/kline/${symbol}.json`,
    ];
    for (const url of jsonUrls) {
      try {
        const raw = await fetchJSON(url);
        const bars = normalizeKlineFromJson(raw);
        if (bars.length) {
          set((state) => ({
            klineMap: { ...state.klineMap, [symbol]: bars },
          }));
          return;
        }
      } catch {
        // 继续尝试下一个路径
      }
    }

    const csvUrls = [`/data/${symbol}.csv`];
    for (const url of csvUrls) {
      try {
        const text = await fetchText(url);
        const bars = normalizeKlineFromCsv(text);
        if (bars.length) {
          set((state) => ({
            klineMap: { ...state.klineMap, [symbol]: bars },
          }));
          return;
        }
      } catch {
        // 继续尝试下一个路径
      }
    }

    console.warn(`[loadKline] no kline for ${symbol}`);
    set((state) => ({
      klineMap: { ...state.klineMap, [symbol]: [] },
    }));
  },

  /** 读取当前 symbol 的自定义水平线集合 */
  getLines(symbol) {
    return get().lineMap[symbol] || [];
  },

  /** 为当前 symbol 添加一条自定义水平线（例如计划买点/止损） */
  addLine(symbol, line) {
    if (!symbol) return;
    set((state) => {
      const prev = state.lineMap[symbol] || [];
      const next = { ...state.lineMap, [symbol]: [...prev, line] };
      return { lineMap: next };
    });
  },

  /** 删除指定水平线 */
  removeLine(symbol, id) {
    if (!symbol) return;
    set((state) => {
      const prev = state.lineMap[symbol] || [];
      const next = {
        ...state.lineMap,
        [symbol]: prev.filter((l) => l.id !== id),
      };
      return { lineMap: next };
    });
  },

  /** 读取某只股票的笔记列表 */
  getNotes(symbol) {
    if (!symbol) return [];
    return get().notesMap[symbol] || [];
  },

  /** 添加一条笔记（存入 localStorage） */
  addNote(symbol, text) {
    if (!symbol || !text.trim()) return;
    const note: Note = {
      id: `n_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      ts: new Date().toISOString(),
      text: text.trim(),
    };
    set((state) => {
      const prev = state.notesMap[symbol] || [];
      const nextMap = {
        ...state.notesMap,
        [symbol]: [note, ...prev],
      };
      saveNotesMap(nextMap);
      return { notesMap: nextMap };
    });
  },

  /** 删除一条笔记 */
  deleteNote(symbol, id) {
    if (!symbol) return;
    set((state) => {
      const prev = state.notesMap[symbol] || [];
      const nextMap = {
        ...state.notesMap,
        [symbol]: prev.filter((n) => n.id !== id),
      };
      saveNotesMap(nextMap);
      return { notesMap: nextMap };
    });
  },
}));
